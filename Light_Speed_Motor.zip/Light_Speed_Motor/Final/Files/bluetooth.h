#ifndef __STM32L476R_NUCLEO_BLUETOOTH_H
#define __STM32L476R_NUCLEO_BLUETOOTH_H

#include "stm32l476xx.h"

#include <stdio.h>
#include <stdbool.h>
#include <math.h>
#include "mode.h"

#define TXBufferSize 32
// Recieved Data is 4 bits
// Bit 0: (0,1) MSB of Speed, (8) Shift Left, (9) Shift Right
// Bit 1 - 3: (0 - 9) Only important for speed and not used if shifting
#define RXBufferSize 4

void UART_Init(void);
void UART1_Init(void);
void UART1_GPIO_Init(void);

void USART_Init(USART_TypeDef* USARTx);

void USART1_IRQHandler(void);

void USART_Write(USART_TypeDef * USARTx, uint8_t *buffer, uint32_t nBytes);
void USART_Delay(uint32_t us);

#endif
