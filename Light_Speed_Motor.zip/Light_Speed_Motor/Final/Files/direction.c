#include "direction.h"

void direction_Init(void) {
	// Enable GPIO A Clock
	RCC->AHB2ENR |= RCC_AHB2ENR_GPIOAEN;
	
	// Set the mode of PA6 to Output (01)
	GPIOA->MODER &= ~(3UL<<12); //clear mode bits
	GPIOA->MODER |= 1UL<<12; // Set mode to output
	
	// Default direction is CCW
	GPIOA->ODR |= 1UL<<6;
}
	
void clockwise(void) {
	GPIOA->ODR &= ~1UL<<6;
}

void counterClockwise(void) {
	GPIOA->ODR |= 1UL<<6;
}
