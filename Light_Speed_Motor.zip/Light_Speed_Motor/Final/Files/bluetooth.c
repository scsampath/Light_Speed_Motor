#include "bluetooth.h"

volatile int putbyte = 0;
volatile int throttle = 0;
volatile bool shifting = false;
int temp = 0;
Mode motorMode;

void UART_Init(void){
	UART1_Init();
	UART1_GPIO_Init();
	USART_Init(USART1);
}

void UART1_Init(void) {
	RCC->APB2ENR |= RCC_APB2ENR_USART1EN;	//enable USART1 clock
	RCC->CCIPR |= RCC_CCIPR_USART1SEL_0;	//Select SYS clock as USART1 clock source
}

void UART1_GPIO_Init(void) {
	RCC->AHB2ENR |= RCC_AHB2ENR_GPIOBEN ; //enable GPIOB clock
	
	// Configure PB6 (TX -> HC05 RX)
		// Set the mode of PB6 to Alternative Function(10)
	GPIOB->MODER &= ~(3UL<<12); //clear mode bits
	GPIOB->MODER |= 2UL<<12; // Set mode to Alternative Function(10)
	GPIOB->AFR[0] &= ~(15<<24); //Clear AFSEL6
	GPIOB->AFR[0] |= 7<<24;  //Set AFSEL6 to AF7 (0111)
	
	// Configure PB7 (RX -> HC05 TX)
		// Set the mode of PB6 to Alternative Function(10)
	GPIOB->MODER &= ~(3UL<<14); //clear mode bits
	GPIOB->MODER |= 2UL<<14; // Set mode to Alternative Function(10)
	GPIOB->AFR[0] &= ~(15<<28); //Clear AFSEL7
	GPIOB->AFR[0] |= 7<<28;  //Set AFSEL7 to AF7 (0111)
	
	GPIOB->OSPEEDR |= GPIO_OSPEEDR_OSPEED6; //PB6 very high speed (11)
	GPIOB->OSPEEDR |= GPIO_OSPEEDR_OSPEED7; //PB7 very high speed (11)
	
	GPIOB->OTYPER &= ~(GPIO_OTYPER_OT6); //PB6 output push pull (0,reset)
	GPIOB->OTYPER &= ~(GPIO_OTYPER_OT7); //PB7 output push pull (0,reset)
	
	GPIOB->PUPDR |= GPIO_PUPDR_PUPD6_0; //PB6 set pull up (01)
	GPIOB->PUPDR |= GPIO_PUPDR_PUPD7_0 ; //PB7 set pull up (01)
	
	// Enable interrupt for USART1;
  NVIC_EnableIRQ(USART1_IRQn); 
	NVIC_SetPriority(USART1_IRQn, 0);
}

void USART_Init(USART_TypeDef* USARTx) {
	USARTx->CR1 &=   ~(USART_CR1_UE);	//USARTx disable
	USARTx->CR1 &=   ~(USART_CR1_M0);	//USARTx M0 reset
	USARTx->CR1 &=   ~(USART_CR1_M1);	//USARTx M1 reset
	USARTx->CR1 &=   ~(USART_CR1_OVER8);	//Oversampling by 16 (0)
	USARTx->CR2 &=   ~(USART_CR2_STOP);	//Number of stop bits = 1 (00)
	USARTx->BRR =	8333;	//Set Baud rate to 9600
	USARTx->CR1 |= USART_CR1_TE;	//Enable Transmit
	USARTx->CR1 |= USART_CR1_RE;	//Enable Recieve
	USARTx->CR1 |= USART_CR1_UE; //USARTx enable
	
	// USARTx Recieve Interrupt Enable
	USARTx->CR1 |= USART_CR1_RXNEIE;
}

// Bluetooth Handler called on Recieve Interrupt
// handles speed control and shifting modes
// For a single data transfer, the interrupt handler is called 4 times, one for each bit
void USART1_IRQHandler(void){
	if(USART1->ISR & USART_ISR_RXNE){
		// Recieved Bit
		char rxByte = (uint8_t) (USART1->RDR & 0xFF);
		
		// Bit 0 
		if(putbyte == 0){
			// set the MSB of speed
			if(rxByte-48 <= 1) {
				temp = pow(10,3)*(rxByte-48);
			}
			// shifting left
			else if(rxByte-48 <= 8){
				shifting = true;
				shiftDown(&motorMode);
			}
			// shifting right
			else if(rxByte-48 <= 9){
				shifting = true;
				shiftUp(&motorMode);
			}
		} 
		
		// Bits 1-3
		// Only important for speed and not used if shifting
		else if(!shifting) {
			temp += pow(10,(3 - putbyte))*(rxByte-48);
		}
		
		putbyte++;
		
		// Reset buffer loop after bit 3 is read
		if(putbyte >= RXBufferSize) {
			throttle = temp;
			putbyte = 0;
			shifting = false;
		}
	}
}

void USART_Write(USART_TypeDef * USARTx, uint8_t *buffer, uint32_t nBytes) {
	int i;
	for (i = 0; i < nBytes; i++) {
		while (!(USARTx->ISR & USART_ISR_TXE));  
		USARTx->TDR = buffer[i] & 0xFF;
		USART_Delay(300);
	}
	while (!(USARTx->ISR & USART_ISR_TC));   		 
	USARTx->ISR &= ~USART_ISR_TC;
}   

void USART_Delay(uint32_t us) {
	uint32_t time = 100*us/7;    
	while(--time);   
}
