#ifndef __STM32L476R_NUCLEO_DIRECTION_H
#define __STM32L476R_NUCLEO_DIRECTION_H

#include "stm32l476xx.h"

void direction_Init(void);
void clockwise(void);
void counterClockwise(void);

#endif
