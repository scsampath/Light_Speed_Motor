/*
 * ECE 153B - Winter 2022
 *
 * Name(s): Sachen Sampath Ryan Chau
 * Final Project
 */
 
#include "stm32l476xx.h"
#include "SysClock.h"

// Motor
#include "PWM.h"
#include "bluetooth.h"

// Display
#include "display.h"

int main() {
	// Initalize System Clock to 80MHz
	System_Clock_Init();
	
	// Motor Initialization
	// Initalize PWM for Motor (PA5)
	PWM_Init();
	// Initalize USART for Bluetooth (PB6 and PB7)
	UART_Init();
	// Initalize Motor Logic
	modeInit(&motorMode);
	// Initalize Direction Logic (PA6)
	direction_Init();
	
	// Display Initialization
	display_Init();
	background_Init();
	
	while(1) {
		int rpm = getModeMultiplier(&motorMode) * throttle;
		TIM2->CCR1 = rpm;
		throttleDraw(throttle);
		rpmDraw(rpm);
		modeDraw(getModeString(&motorMode));
	}
	return 0;
}
