#include "SPI.h"
#include "SysTimer.h"

// Note: When the data frame size is 8 bit, "SPIx->DR = byte_data;" works incorrectly. 
// It mistakenly send two bytes out because SPIx->DR has 16 bits. To solve the program,
// we should use "*((volatile uint8_t*)&SPIx->DR) = byte_data";
#define PB_MOSI (15)
#define PB_SCK  (13)
#define PB_DC   (14)
#define PA_CS   (12)
#define PA_RST  (11)

//PB15-MOSI, PB13-SCK, PB14-DC 
//PA12-CS, PA15-RST

void SPI_GPIO_Init(void) {
	//initialize SPI GPIOB pins
	RCC->AHB2ENR |= RCC_AHB2ENR_GPIOBEN ; //enable GPIOB clock
	
	//clear mode bits
	GPIOB->MODER   &= ~((0x3 << (PB_MOSI * 2)) |
											(0x3 << (PB_SCK  * 2)) |
											(0x3 << (PB_DC   * 2)));
	
	// Set the MOSI and SCK pins to alternate function mode 0.
	// Set D/C to normal output.		
	GPIOB->AFR[1] &= ~(15<<20); //Clear AFSEL13
	GPIOB->AFR[1] |= 5<<20;  //Set AFSEL13 to AF5 (0101)
	GPIOB->AFR[1] &= ~(15<<28); //Clear AFSEL15
	GPIOB->AFR[1] |= 5<<28;  //Set AFSEL15 to AF5 (0101)
	
	GPIOB->MODER   |=  ((0x2 << (PB_MOSI * 2)) |
											(0x2 << (PB_SCK  * 2)) |
											(0x1 << (PB_DC   * 2)));
	
	// Use pull-up for peripheral
	GPIOB->PUPDR   &= ~((0x3 << (PB_MOSI * 2)) |
											(0x3 << (PB_SCK  * 2)) |
											(0x3 << (PB_DC   * 2)));
	GPIOB->PUPDR  |=   ((0x1 << (PB_MOSI * 2)) |
											(0x1 << (PB_SCK  * 2)));
											
	// Output type: Push-pull
	GPIOB->OTYPER  &= ~((0x1 << PB_MOSI) |
											(0x1 << PB_SCK)  |
											(0x1 << PB_DC));
	
	// High-speed 
	// (Setting all '1's, so no need to clear bits first.)
	GPIOB->OSPEEDR |=  ((0x3 << (PB_MOSI * 2)) |
											(0x3 << (PB_SCK  * 2)) |
											(0x3 << (PB_DC   * 2)));
											
	//initialize SPI GPIOA pins
	RCC->AHB2ENR |= RCC_AHB2ENR_GPIOAEN ; //enable GPIOA clock
	//clear mode bits
	GPIOA->MODER   &= ~((0x3 << (PA_CS   * 2)) |
											(0x3 << (PA_RST  * 2)));
	// Set PA12/PA11 to normal output.											
	GPIOA->MODER   |=  ((0x1 << (PA_CS   * 2)) |
											(0x1 << (PA_RST  * 2)));
	// Output type: Push-pull										
	GPIOA->OTYPER  &= ~((0x1 << PA_CS) |
											(0x1 << PA_RST));								
	// Use pull-up for peripheral									
	GPIOA->PUPDR   &= ~((0x3 << (PA_CS  * 2)) |
											(0x3 << (PA_RST * 2)));
}

void SPI2_Init(void){
	// TODO: initialize SPI2 peripheral
	
	//Enable the SPI clock
	RCC->APB1ENR1 |= RCC_APB1ENR1_SPI2EN;
	
	// Make sure that the peripheral is off, and reset it
	SPI2->CR1 &= ~(SPI_CR1_SPE);
	RCC->APB1RSTR1 |= RCC_APB1RSTR1_SPI2RST;
	RCC->APB1RSTR1 &= ~(RCC_APB1RSTR1_SPI2RST);
	
	// Set clock polarity and phase.
	SPI2->CR1 |=  (SPI_CR1_CPOL |
								 SPI_CR1_CPHA);

	// Set the STM32 to act as a host device.
	SPI2->CR1 |= SPI_CR1_MSTR;
	
	// Set software 'Chip Select' pin.
	SPI2->CR1 |= SPI_CR1_SSM;
	
	// (Set the internal 'Chip Select' signal.)
	SPI2->CR1 |= SPI_CR1_SSI;
	
	// Enable the peripheral.
	SPI2->CR1 |=  SPI_CR1_SPE;
}

void hspi_w8(SPI_TypeDef *SPIx, uint8_t dat) {
  // Wait for TXE.
  while (!(SPIx->SR & SPI_SR_TXE)) {};
  // Send the byte.
  *(uint8_t*)&(SPIx->DR) = dat;
}

void hspi_w16(SPI_TypeDef *SPIx, uint16_t dat) {
  hspi_w8(SPIx, (uint8_t)(dat >> 8));
  hspi_w8(SPIx, (uint8_t)(dat & 0xFF));
}
 
void hspi_cmd(SPI_TypeDef *SPIx, uint8_t cmd) {
  while ((SPIx->SR & SPI_SR_BSY)) {};
  GPIOB->ODR &= ~(1 << PB_DC);
  hspi_w8(SPIx, cmd);
  while ((SPIx->SR & SPI_SR_BSY)) {};
  GPIOB->ODR |=  (1 << PB_DC);
}

//void ILI9341_Enable(void) {
//	GPIOA->ODR |= GPIO_ODR_OD11;
//}

//void ILI9341_Reset(void) {
//	GPIOA->ODR &= ~GPIO_ODR_OD11;
//	for(int i = 0; i<2000000;i++);
//	GPIOA->ODR &= ~GPIO_ODR_OD12;
//	for(int i = 0; i<2000000;i++);
//	GPIOA->ODR |= GPIO_ODR_OD11;
//}

//void ili9341_hspi_init(SPI_TypeDef *SPIx) {

//ILI9341_Enable();
//ILI9341_Reset();
//	
////SOFTWARE RESET
//hspi_cmd(SPIx, 0x01);
//for(int i = 0; i<2000000;i++);
////delay(100);
//    
////POWER CONTROL A
//hspi_cmd(SPIx, 0xCB);
//hspi_w8(SPIx, 0x39);
//hspi_w8(SPIx, 0x2C);
//hspi_w8(SPIx, 0x00);
//hspi_w8(SPIx, 0x34);
//hspi_w8(SPIx, 0x02);

////POWER CONTROL B
//hspi_cmd(SPIx, 0xCF);
//hspi_w8(SPIx, 0x00);
//hspi_w8(SPIx, 0xC1);
//hspi_w8(SPIx, 0x30);

////DRIVER TIMING CONTROL A
//hspi_cmd(SPIx, 0xE8);
//hspi_w8(SPIx, 0x85);
//hspi_w8(SPIx, 0x00);
//hspi_w8(SPIx, 0x78);

////DRIVER TIMING CONTROL B
//hspi_cmd(SPIx, 0xEA);
//hspi_w8(SPIx, 0x00);
//hspi_w8(SPIx, 0x00);

////POWER ON SEQUENCE CONTROL
//hspi_cmd(SPIx, 0xED);
//hspi_w8(SPIx, 0x64);
//hspi_w8(SPIx, 0x03);
//hspi_w8(SPIx, 0x12);
//hspi_w8(SPIx, 0x81);

////PUMP RATIO CONTROL
//hspi_cmd(SPIx, 0xF7);
//hspi_w8(SPIx, 0x20);

////POWER CONTROL,VRH[5:0]
//hspi_cmd(SPIx, 0xC0);
//hspi_w8(SPIx, 0x23);

////POWER CONTROL,SAP[2:0];BT[3:0]
//hspi_cmd(SPIx, 0xC1);
//hspi_w8(SPIx, 0x10);

////VCM CONTROL
//hspi_cmd(SPIx, 0xC5);
//hspi_w8(SPIx, 0x3E);
//hspi_w8(SPIx, 0x28);

////VCM CONTROL 2
//hspi_cmd(SPIx, 0xC7);
//hspi_w8(SPIx, 0x86);

////MEMORY ACCESS CONTROL
//hspi_cmd(SPIx, 0x36);
//hspi_w8(SPIx, 0x48);

////PIXEL FORMAT
//hspi_cmd(SPIx, 0x3A);
//hspi_w8(SPIx, 0x55);

////FRAME RATIO CONTROL, STANDARD RGB COLOR
//hspi_cmd(SPIx, 0xB1);
//hspi_w8(SPIx, 0x00);
//hspi_w8(SPIx, 0x18);

////DISPLAY FUNCTION CONTROL
//hspi_cmd(SPIx, 0xB6);
//hspi_w8(SPIx, 0x08);
//hspi_w8(SPIx, 0x82);
//hspi_w8(SPIx, 0x27);

////3GAMMA FUNCTION DISABLE
//hspi_cmd(SPIx, 0xF2);
//hspi_w8(SPIx, 0x00);

////GAMMA CURVE SELECTED
//hspi_cmd(SPIx, 0x26);
//hspi_w8(SPIx, 0x01);

////POSITIVE GAMMA CORRECTION
//hspi_cmd(SPIx, 0xE0);
//hspi_w8(SPIx, 0x0F);
//hspi_w8(SPIx, 0x31);
//hspi_w8(SPIx, 0x2B);
//hspi_w8(SPIx, 0x0C);
//hspi_w8(SPIx, 0x0E);
//hspi_w8(SPIx, 0x08);
//hspi_w8(SPIx, 0x4E);
//hspi_w8(SPIx, 0xF1);
//hspi_w8(SPIx, 0x37);
//hspi_w8(SPIx, 0x07);
//hspi_w8(SPIx, 0x10);
//hspi_w8(SPIx, 0x03);
//hspi_w8(SPIx, 0x0E);
//hspi_w8(SPIx, 0x09);
//hspi_w8(SPIx, 0x00);

////NEGATIVE GAMMA CORRECTION
//hspi_cmd(SPIx, 0xE1);
//hspi_w8(SPIx, 0x00);
//hspi_w8(SPIx, 0x0E);
//hspi_w8(SPIx, 0x14);
//hspi_w8(SPIx, 0x03);
//hspi_w8(SPIx, 0x11);
//hspi_w8(SPIx, 0x07);
//hspi_w8(SPIx, 0x31);
//hspi_w8(SPIx, 0xC1);
//hspi_w8(SPIx, 0x48);
//hspi_w8(SPIx, 0x08);
//hspi_w8(SPIx, 0x0F);
//hspi_w8(SPIx, 0x0C);
//hspi_w8(SPIx, 0x31);
//hspi_w8(SPIx, 0x36);
//hspi_w8(SPIx, 0x0F);

////EXIT SLEEP
//hspi_cmd(SPIx, 0x11);
////delay(100);
//for(int i = 0; i<2000000;i++);
////TURN ON DISPLAY
//hspi_cmd(SPIx, 0x29);

//}
