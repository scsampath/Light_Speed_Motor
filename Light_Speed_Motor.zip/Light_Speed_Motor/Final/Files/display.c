#include "display.h"

int prevThrottle;
int prevRPM;
char* prevMode;

void display_Init(void) {
	SysTick_Init();
	SPI_GPIO_Init();
	SPI2_Init();
	ILI9341_Init();
}

void background_Init(void) {
	ILI9341_SetRotation(SCREEN_VERTICAL_2);
	ILI9341_FillScreen(0x0000);
	// Title
	ILI9341_DrawText("LIGHTSPEED MOTOR", FONT3, 45, 30, WHITE, BLACK);
	
	// Throttle Bar
	ILI9341_DrawText("Throttle: ", FONT3, 30, 195, WHITE, BLACK);
	ILI9341_DrawText("0", FONT3, 35, 170, WHITE, BLACK);
	ILI9341_DrawText("50", FONT3, 25, 122, WHITE, BLACK);
	ILI9341_DrawText("100", FONT3, 20, 75, WHITE, BLACK);
	ILI9341_DrawHLine(45,179,5,WHITE);
	ILI9341_DrawHLine(45,169,5,WHITE);
	ILI9341_DrawHLine(45,159,5,WHITE);
	ILI9341_DrawHLine(45,149,5,WHITE);
	ILI9341_DrawHLine(45,139,5,WHITE);
	ILI9341_DrawHLine(45,129,5,WHITE);
	ILI9341_DrawHLine(45,119,5,WHITE);
	ILI9341_DrawHLine(45,109,5,WHITE);
	ILI9341_DrawHLine(45,99,5,WHITE);
	ILI9341_DrawHLine(45,89,5,WHITE);
	ILI9341_DrawHLine(45,80,5,WHITE);
	
	// RPM Bar
	ILI9341_DrawText("RPM: ", FONT3, 145, 195, WHITE, BLACK);
	ILI9341_DrawText("0", FONT3, 140, 170, WHITE, BLACK);
	ILI9341_DrawText("3000", FONT3, 115, 122, WHITE, BLACK);
	ILI9341_DrawText("6000", FONT3, 115, 75, WHITE, BLACK);
	ILI9341_DrawHLine(150,179,5,WHITE);
	ILI9341_DrawHLine(150,169,5,WHITE);
	ILI9341_DrawHLine(150,159,5,WHITE);
	ILI9341_DrawHLine(150,149,5,WHITE);
	ILI9341_DrawHLine(150,139,5,WHITE);
	ILI9341_DrawHLine(150,129,5,WHITE);
	ILI9341_DrawHLine(150,119,5,WHITE);
	ILI9341_DrawHLine(150,109,5,WHITE);
	ILI9341_DrawHLine(150,99,5,WHITE);
	ILI9341_DrawHLine(150,89,5,WHITE);
	ILI9341_DrawHLine(150,80,5,WHITE);
	
	// Mode Display
	ILI9341_DrawText("Mode: ", FONT3, 30, 250, WHITE, BLACK);
}

void throttleDraw(int throt){
	if(prevThrottle != throt){
		char char_arr [10];

		// Draws Bar
		ILI9341_DrawRectangle(50,80,40,100-(throt/10),0x0000);
		ILI9341_DrawRectangle(50,180-(throt/10),40,throt/10    ,0xF800);

		// Draws Text
		sprintf(char_arr, "%d", throt/10);
		ILI9341_DrawRectangle(90,195,30,15,0x0000);
		ILI9341_DrawText(char_arr, FONT3, 90, 195, WHITE, BLACK);
		prevThrottle = throt;
	}
}

void rpmDraw(int rpm) {
	if(prevRPM != rpm){
		char char_arr [10];
	
		// Draws Bar
		ILI9341_DrawRectangle(155,80,40,100-(rpm/60),0x0000);
		ILI9341_DrawRectangle(155,180-(rpm/60),40,(rpm/60)    ,0x001F);

		// Draws Text
		sprintf(char_arr, "%d", rpm);
		ILI9341_DrawRectangle(185,195,30,15,0x0000);
		ILI9341_DrawText(char_arr, FONT3, 185, 195, WHITE, BLACK);
		prevRPM = rpm;
	}
}

void modeDraw(char* mode){
	if(prevMode != mode){
		ILI9341_DrawRectangle(75,250,70,15,0x0000);
		ILI9341_DrawText(mode, FONT3, 75, 250, WHITE, BLACK);
		prevMode = mode;
	}
}
