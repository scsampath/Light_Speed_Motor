#ifndef __STM32L476R_NUCLEO_DISPLAY_H
#define __STM32L476R_NUCLEO_DISPLAY_H

#include "stm32l476xx.h"

// Display
#include "SPI.h"
#include "SysTimer.h"
#include "ILI9341_STM32_Driver.h"
#include "ILI9341_GFX.h"
#include "fonts.h"

#include <stdio.h>
#include <string.h>

void display_Init(void);

void background_Init(void);

void throttleDraw(int throt);

void rpmDraw(int throt);

void modeDraw(char* mode);

#endif
