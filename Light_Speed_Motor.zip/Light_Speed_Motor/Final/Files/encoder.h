#ifndef __STM32L476G_DISCOVERY_ENCODER_H
#define __STM32L476G_DISCOVERY_ENCODER_H

#include "stm32l476xx.h"

void encoder_Init(void);

#endif /* __STM32L476G_DISCOVERY_PWM_H */
