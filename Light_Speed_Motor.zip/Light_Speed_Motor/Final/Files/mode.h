#ifndef __STM32L476R_NUCLEO_MODE_H
#define __STM32L476R_NUCLEO_MODE_H

#include "stm32l476xx.h"
#include "direction.h"

// Mode class for motor
// Mode 0: Reverse | Multiplier = 1
// Mode 1: Stopped | Multiplier = 0
// Mode 2: Low     | Multiplier = 1
// Mode 3: Medium  | Multiplier = 3
// Mode 4: High    | Multiplier = 5
// Mode 5: High+   | Multiplier = 6

typedef struct {
	int number;
	int multiplier;
} Mode;

extern Mode motorMode;
volatile extern int throttle;

void modeInit(Mode *m);

int getModeMultiplier(Mode *m);

char* getModeString(Mode *m);

int getModeNumber(Mode *m);

void shiftDown(Mode *m);

void shiftUp(Mode *m);

#endif
