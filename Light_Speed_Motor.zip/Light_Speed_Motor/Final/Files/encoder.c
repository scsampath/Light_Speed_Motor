#include "encoder.h"
// PA7 Encoder
void encoder_Init(void) {
	// Enable GPIO Port A Clock
	RCC->AHB2ENR |= RCC_AHB2ENR_GPIOAEN;
	
	// Enable TIM2 Clock
	RCC->APB1ENR1 |= 1UL;
	
	// Configure PA5
		// Set the mode of PA5 to Alternative Function(10)
  GPIOA->MODER &= ~(3UL<<10); //clear mode bits
	GPIOA->MODER |= 2UL<<10; // Set mode to Alternative Function(10)
	
		// Set PA5 to Very High Output Speed(11)
	GPIOA->OSPEEDR &= ~(3UL<<10); //clear mode bits
	GPIOA->OSPEEDR |= 3UL<<10; //Set mode to Very High(11)
	
		// Set PA5 to No Pull-Up, No Pull-Down (00,reset)
	GPIOA->PUPDR &= ~(3UL<<10); //clear mode bits
	
		// AFSEL5 for pin 5, AF1 for PA5 TIM2_CH1
	GPIOA->AFR[0] |= GPIO_AFRL_AFSEL5_0;  
	
	
	// Configure PWM Output for TIM2 CH 1
	TIM2->CR1 &= ~TIM_CR1_DIR; //DIR = 0 for upcounter
	
	TIM2->PSC = 79UL; //Set the prescaler value
	
	TIM2->ARR = 6000UL; //Set the auto-reload value
	
	TIM2->CCMR1 &= ~(7UL<<4); //Clear output compare mode bits
	TIM2->CCMR1 |= 6UL<<4; //Set output compare mode bits to PWM mode 1 (0110)
	TIM2->CCMR1 |= 1UL<<3; //Output compare preload enable
	
	TIM2->CCER &= ~(1UL<<1);//Set the output polarity for compare 1 to active high (0)
	TIM2->CCER |= 1UL;//Enable the channel 1 output
	
	TIM2->CCR1 = 0UL; //Set the capture/compare value.
	
	TIM2->CR1 |= TIM_CR1_CEN; //enable the counter
}
