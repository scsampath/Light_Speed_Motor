#include "mode.h"

// Intializes Mode Struct
// Default Mode is Stopped
void modeInit(Mode *m){
	m->number = 1;
	m->multiplier = 0;
}

// Gets Mode Multiplier
int getModeMultiplier(Mode *m) {
	return m->multiplier;
}

// Gets Mode String using Mode Number
char* getModeString(Mode *m){
	switch(m->number) {
		case 0 :
			return "Reverse";
		case 2 :
			return "Low";
		case 3 :
			return "Medium";
		case 4 :
			return "High";
		case 5 :
			return "High+";
		default :
			return "Stopped";
	}
}

// Gets Mode Number
int getModeNumber(Mode *m) {
	return m->number;
}

// Local Function
// Gets Multiplier using Mode Number
int getMultiplier(int modeNumber){
	switch(modeNumber) {
		case 0 :
		case 2 :
			return 1;
		case 3 :
			return 3;
		case 4 :
			return 5;
		case 5 :
			return 6;
		default :
			return 0;
	}
}

// Shift Left
void shiftDown(Mode *m) {
	m->number -= 1;
	m->multiplier = getMultiplier(m->number);
	if(m->number == 0) {
		clockwise();
	}
}

// Shift Right
void shiftUp(Mode *m) {
	if(m->number == 1) {
		counterClockwise();
	}
	m->number += 1;
	m->multiplier = getMultiplier(m->number);
}
